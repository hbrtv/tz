# PHP 雅黑探针

探针来自 ： http://www.yahei.net 

## Docker启动
```
docker run -d --name tz -p 80:80 malaohu/php-yahei-tz
```
